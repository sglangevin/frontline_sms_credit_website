<?php
/**
 * @package		My Blog
 * @copyright (C) 2008 by Slashes & Dots Sdn Bhd - All rights reserved!
 * @license http://www.azrul.com Copyrighted Commercial Software
 */
defined('_JEXEC') or die('Restricted access');

define( "SITE_ROOT_PATH", JPATH_ROOT );

jimport( 'joomla.filesystem.file' );
jimport( 'joomla.filesystem.folder' );
jimport( 'joomla.filesystem.archive' );

function com_install()
{
	global $_VERSION, $option, $my;
	ob_start();
	
	$mainframe	=& JFactory::getApplication();
	
	// Include the admin functions
	require_once (SITE_ROOT_PATH. "/administrator/components/com_myblog/functions.admin.php");
	
	// Check if older Jom COmment is installed.
	if(myCheckOldJomComment())
	{
		echo '<h3 style="color: red;">Installation FAILS! Older version of Jom Comment detected!</h3>';
		echo "<p>Please update your version of Jom Comment before proceeding with the installation of My Blog!</p>";
		return;
	}

	$db		=& JFactory::getDBO();

	$db->setQuery("UPDATE #__components SET admin_menu_img='../administrator/components/com_myblog/images/myblog-icon.png' WHERE admin_menu_link='option=com_myblog'");
	$db->query();
	
	// Load installation script
	require_once( JPATH_ROOT . DS . 'administrator' . DS . 'components' . DS . 'com_myblog' . DS . 'install.sql.php' );

	myFixDashboardLinks();
	myFixMenuLinks();
	myFixDBTables();
	
	// unpack all zipped files
	myExtractFiles();
?>

<p><img src="<?php rtrim( JURI::root() , '/' );?>/components/com_myblog/images/pageicon.png" alt="logo" /></p>
<p><strong>My Blog</strong><br/>
<code>
<br />
<style>
.CommonTextButtonBig, .CommonTextButtonSmall {
background-color:#EEEEEE;
border-color:#CCCCCC rgb(153, 153, 153) rgb(153, 153, 153) rgb(204, 204, 204);
border-style:solid;
border-width:1px;
color:#333333;
display:-moz-inline-box;
font-family:Tahoma,Arial,Helvetica;
font-size:120%;
margin:1px;
padding:10px;
vertical-align:middle;
white-space:nowrap;
}
.CommonTextButtonSmall {
font-size:100%;
padding:2px 3px 3px 2px;
text-align:center;
}
input.CommonTextButtonBig {
color:#000000;
font-size:150%;
font-weight:bold;
text-align:left;
}
input.CommonTextButtonSmall {
text-align:left;
}
a.CommonTextButtonSmall {
cursor:pointer;
}
input.CommonTextButtonSmall:hover, input.CommonTextButtonSmall:active, input.CommonTextButtonSmall:focus, input.CommonTextButtonBig:hover, input.CommonTextButtonBig:active, input.CommonTextButtonBig:focus {
background-color:#FFFFFF;
}
.CommonTextButtonBig:hover, .CommonTextButtonSmall:hover {
background-color:#DDDDDD;
border-color:#CCCCCC rgb(153, 153, 153) rgb(153, 153, 153) rgb(204, 204, 204);
border-style:solid;
border-width:1px;
color:#333333;
text-decoration:none;
}
</style>
<?php
	echo '<img src="images/tick.png"> Creating database tables<br/><br/>';
    
    $db->setQuery("SELECT id from #__sections WHERE title='MyBlog'");
	$sectionid = $db->loadResult();
	
	if ($sectionid)
	{
		echo '<img src="images/tick.png"> Previous MyBlog section found. Republishing section.<br/><br/>';
		$db->setQuery("UPDATE #__sections SET published = 1 WHERE id = $sectionid");
		$db->query();
	}
	else
	{
		echo '<img src="images/tick.png"> Creating MyBlog section. <br/><br/>';
		$db->setQuery("INSERT INTO #__sections SET published = 1, title='MyBlog', name='MyBlog', scope='content', count=1, ordering=1");
		$db->query();
		$sectionid = $db->insertid();
	}

	// Upgrade for feedburner
	$fields	= $db->getTableFields( '#__myblog_user' );
	
	if(!empty($fields))
	{
        if(!array_key_exists("feedburner", $fields['#__myblog_user'] ))
		{
			// Add new 'feedburner' column
			$strSQL = "ALTER TABLE `#__myblog_user` ADD `feedburner` TEXT NOT NULL";
			$db->setQuery($strSQL);
			$db->query();
        }

        if(!array_key_exists("googlegears", $fields['#__myblog_user'] ))
		{
			// Add new 'googlegears' column
			$strSQL = "ALTER TABLE `#__myblog_user` ADD `googlegears` INT NOT NULL DEFAULT '0'";
			$db->setQuery($strSQL);
			$db->query();
        }

        if(!array_key_exists("style", $fields['#__myblog_user'])){
			// Add new 'feedburner' column
			$strSQL = "ALTER TABLE `#__myblog_user` ADD `style` TEXT NOT NULL";
			$db->setQuery($strSQL);
			$db->query();
        }
        
		if(!array_key_exists("title", $fields['#__myblog_user'] )){
			// Add new 'feedburner' column
			$strSQL = "ALTER TABLE `#__myblog_user` ADD `title` TEXT NOT NULL";
			$db->setQuery($strSQL);
			$db->query();
        }
	}

	// Upgrade myblog_categories table structure.
	$fields	= $db->getTableFields( '#__myblog_categories' );
	
	if(!empty($fields))
	{
		if(!array_key_exists('default', $fields['#__myblog_categories'] ))
		{
			$strSQL	= 'ALTER TABLE `#__myblog_categories` ADD `default` TINYINT NOT NULL';
			$db->setQuery($strSQL);
			$db->query();
			
			$strSQL	= 'ALTER TABLE `#__myblog_categories` ADD INDEX ( `default` )';
			$db->setQuery($strSQL);
			$db->query();			
		}

		if(!array_key_exists('slug', $fields['#__myblog_categories'] ))
		{
			$strSQL	= 'ALTER TABLE `#__myblog_categories` ADD `slug` VARCHAR(255) NOT NULL';
			$db->setQuery($strSQL);
			$db->query();
		}
	}

    $db->setQuery("SELECT id from #__categories WHERE title='MyBlog'");
	$catid = $db->loadResult();
	
	if ($catid)
	{
		$db->setQuery("UPDATE #__categories SET published = 1 WHERE id = $catid");
		$db->query();
	}
	else
	{
		$db->setQuery("INSERT INTO #__categories SET published = 1, title='MyBlog', name='MyBlog', section=$sectionid, ordering=1");
		$db->query();
		$catid = $db->insertid();
	}

	// All Files has been unpacked, call CONFIG file once to initialise the default config
	require_once( JPATH_ROOT . DS . 'administrator' . DS . 'components' . DS . 'com_myblog' . DS . 'config.myblog.php' );
	$cfgObject = new MYBLOG_Config();

	echo '<strong>Creating default menu items</strong><br/>';
	echo '<img src="images/tick.png"> Creating User Menu item - MyBlog Dashboard<br/><br/>';
	echo '<strong>Installing System Mambots</strong><br/>';

    # check if azrul system mambot is installed (for ajax stuff)
    $src	= JPATH_ROOT . DS . 'components' . DS . 'com_myblog' . DS . 'azrul.zip';
    sysBotUpgrade($src);

	# Check if azvideo bot is installed
	$src	= JPATH_ROOT . DS . 'components' . DS . 'com_myblog' . DS . 'azvideobot.zip';
	installAzvideoBot($src);


	echo '<strong>Checking configuration settings</strong><br/>';

	$db->setQuery("SELECT id FROM #__components WHERE `option`='com_jomcomment'");
	$jomcommentExists = $db->loadResult();



	echo '<br/>';

	echo 'Installation completed. <br/> Thank you for using MyBlog! <br/>Click the button below to configure MyBlog.<br/><br/>';
	// echo 'Preliminary installation completed. <br/>
	//		Please click the button below to complete this installation.<br/><br/>';

	echo '<a class="CommonTextButtonBig" href="index2.php?option=com_myblog">Continue&nbsp;&nbsp;<img align="absmiddle" border="0" src="components/com_myblog/Forward_16x16.png" /></a>';
?>

<br />
	</code>
  	<font class="small">&copy; Copyright 2006 by Azrul<br />
  	This component is copyrighted commercial software. Distribution is prohibited.</font></p>
	<p><a href="http://www.azrul.com">www.azrul.com</a></p><br /><br /><br /><br />


  <?php
	$content    = ob_get_contents();
	ob_end_clean();
	
	# after the installation, we need to delete the zip file leftover
// 	$installfiles = array('admin.zip', 'com.zip', 'azrul.zip','cmslib.zip', 'azvideobot.php');
// 	foreach($installfiles as $f)
// 	{
// 		//if (file_exists($cms->get_path("root") . "/components/com_myblog/$f"))
// 		//		myUnlink(file_exists($cms->get_path("root") . "/components/com_myblog/$f"));
// 	}
	
	return $content;
	
}

/**
 * Create 2 menu items.
 *  1. in "main menu", called "Blog"
 *  2. in "user menu", called "My Blog Entries"
 *
 * If the menu already exist, do not re-create them, Just re-publish them
 */
function sysBotGetVersion()
{
	$version = 0;
	
	// check jomcomment version
	// Read the file to see if it's a valid component XML file
	$parser		=& JFactory::getXMLParser('Simple');
	$path		= JPATH_ROOT . DS . 'plugins' . DS . 'system' . DS . 'azrul.system.xml';
	
	if( JFile::exists( $path ) )
	{
		$parser->loadFile($path);
		$document	=& $parser->document;
		
		$element	=& $document->getElementByPath('version' , 1 );
		$version	= isset( $element ) ? $element->data() : '';
	}
	
	return doubleval( $version );
}


function sysBotUpgrade($src)
{
    $installIt	= false;
    
	$botVersion = sysBotGetVersion();
	$db			=& JFactory::getDBO();
	
	if($botVersion != 0 && $botVersion < 2.8 )
	{
		JFolder::delete( JPATH_ROOT . DS . 'plugins' . DS . 'system' . DS . 'pc_includes' );

		JFile::delete( JPATH_ROOT . DS . 'plugins' . DS . 'system' . DS . 'azrul.system.php' );
		JFile::delete( JPATH_ROOT . DS . 'plugins' . DS . 'system' . DS . 'azrul.system.xml' );

		$strSQL = "DELETE FROM #__plugins WHERE element='azrul.system'";
		$db->setQuery( $query );
		$db->query();

	    $installIt = true;
	}
	else if($botVersion == 0)
	{
		// No system bot detected, install it
		$installIt = true;
	}

	
	if($installIt)
	{
		echo '<img src="images/tick.png"> Installing Azrul.com System mambots <br/>';
				
		JArchive::extract( $src , JPATH_ROOT . DS . 'plugins' . DS . 'system' );
	    
	    $strSQL = "DELETE FROM #__plugins WHERE element='azrul.system' OR `name`='Azrul.com System Mambot'";
	    $db->setQuery($strSQL);
	    $db->query();
	    
	    $strSQL = "INSERT INTO `#__plugins` SET `name`='Azrul.com System Mambot', "
	            . "`element`='azrul.system', "
	            . "`folder`='system', "
	            . "`access`='0', "
	            . "`ordering`='1', "
	            . "`published`='1'";
		$db->setQuery($strSQL);
		$db->query();
	}
}

/**
 * Install Azrul's videobot
 **/
function installAzvideoBot($zipSrc)
{
	$exists		= false;
	$db			=& JFactory::getDBO();
		
	/**
	 * Check if existing video mambot exists
	 **/
	$strSQL = "SELECT * FROM #__plugins WHERE `element`='azvideobot' AND `folder`='content'";
	$db->setQuery($strSQL);
	
	if($db->loadResult())
	{
		$exists = true;

		if( JFile::exists( JPATH_ROOT . DS . 'plugins' . DS . 'content' . DS . 'azvideobot.php' ) )
		{
			JFile::delete( JPATH_ROOT . DS . 'plugins' . DS . 'content' . DS . 'azvideobot.php' );
		}
		
		if( JFile::exists( JPATH_ROOT . DS . 'plugins' . DS . 'content' . DS . 'azvideobot.xml' ) )
		{
			JFile::delete( JPATH_ROOT . DS . 'plugins' . DS . 'content' . DS . 'azvideobot.xml' );
		}
	}

    echo '<img src="images/tick.png"> Installing Azrul Videobot<br />';
    JArchive::extract($zipSrc , JPATH_ROOT . DS . 'plugins' . DS . 'content' );

    if(!$exists)
	{
		$query  	= "INSERT INTO #__plugins SET `name`='Azrul Video Mambot', "
		        	. "`element`='azvideobot', `folder`='content', "
		        	. "`access`='0', `ordering`='0', `published`='1', `params`='height=350px
					  width=425px'";
		$db->setQuery( $query );
		$db->query();
	}
	
	unset($archive);

}/* End installAzvideoBot */

function showInstallWizard()
{
	$mainframe	=& JFactory::getApplication();
	$db			=& JFactory::getDBO();
?>
<link href="<?php echo rtrim( JURI::root() , '/' );?>/components/com_myblog/css/admin_style.css" rel="stylesheet" type="text/css">
<table width="100%" border="0" cellspacing="4" cellpadding="4">
    <tr>
        <td><table width="100%" class="mytable" border="0" cellspacing="2" cellpadding="2">
                <tr>
                    <th>Step 1 : Create a link to the blog-writig page in the user's menu </th>
                </tr>
                <tr>
                    <td><blockquote>You need to create a link to your new blog component in one of your menu. </blockquote></td>
                </tr>
                <tr>
                    <td><blockquote>
                            <form name="form1">
                                <label for="select"></label>
                                <select name="menutype" id="menutype">
                                <?php
									$db->setQuery("SELECT distinct(menutype) from #__menu");
									$menutypes = $db->loadObjectList();
									foreach($menutypes as $menu)
									{
										echo "<option value=\"$menu->menutype\">$menu->menutype</option>";
									}
								?>
                                </select>
                                <label for="Submit"></label>
                                <input onclick = "var w;w=window.open('index2.php?option=com_menus&menutype=mainmenu&task=edit&type=url&link=hello', 'menu1');

												el.value='MyBlog Entries';
												el=w.document.getElementByName('link');
												el.setAttribute('value', 'index.php?option=com_myblog&task=startadmin');" type="button" name="button" value="Create the menu now." id="button1">
                            </form>
                        </blockquote></td>
                </tr>
                <tr>
                    <td>&nbsp;</td>
                </tr>
            </table>
            <table width="100%"  class="mytable"  border="0" cellspacing="2" cellpadding="2">
                <tr>
                    <th valign="middle">Step 2 : Create a link to the blog-writig page in the user's menu </th>
                </tr>
                <tr>
                    <td><blockquote>You need to create a link to your new blog component in one of your menu. </blockquote></td>
                </tr>
                <tr>
                    <td><blockquote>
                            <form name="form1" method="post" action="" target="_blank">
                                <label for="select"></label>
                                <select name="select" id="select">
                                    <?php
										$db->setQuery("SELECT distinct(menutype) from #__menu");
										$menutypes = $db->loadObjectList();
										foreach($menutypes as $menu)
										{
											echo "<option value=\"$menu->menutype\">$menu->menutype</option>";
										}
								?>
                                </select>
                                <label for="Submit"></label>
                                <input type="submit" name="Submit" value="Create the menu now." id="Submit">
                            </form>
                        </blockquote></td>
                </tr>
                <tr>
                    <td>&nbsp;</td>
                </tr>
            </table>
            <table width="100%" class="mytable"  border="0" cellspacing="2" cellpadding="2">
                <tr>
                    <th>Step 3 : Make sure all the links are published </th>
                </tr>
                <tr>
                    <td><blockquote>You need to create a link to your new blog component in one of your menu. </blockquote></td>
                </tr>
                <tr>
                    <td><blockquote>
                            <form name="form2" method="post" action="">
                                <label for="label"></label>
                                <input type="submit" name="Submit2" value="Publish all the menu items" id="label">
                            </form>
                        </blockquote></td>
                </tr>
                <tr>
                    <td>&nbsp;</td>
                </tr>
            </table></td>
    </tr>
</table>
<?php

}
