drop table if exists `#__blog_postings`;
drop table if exists `#__blog_comment`;
drop table if exists `#__blog_myaccount`;
