WP-THEMES BLOGGER THEME
http://www.wp-them.es/wp-themes-blogger-theme/

INSTALL: 
1. Upload the theme folder via FTP to your wp-content/themes/ directory.
2. Go to Admin WordPress and select Appearance.
3. Select Wp-Them.es Magazine WordPress theme.



Wordpress Theme by
theme.directory@gmail.com
http://www.wp-them.es